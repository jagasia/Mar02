import java.util.Iterator;
import java.util.TreeSet;

public class DescendingIteratorDemo1 {

	public static void main(String[] args) {
		TreeSet<Integer> marks=new TreeSet<Integer>();
		marks.add(25);
		marks.add(125);
		marks.add(2151);
		marks.add(252);
		marks.add(225);
		marks.add(225);
		marks.add(325);
		marks.add(2353);
		marks.add(425);
		marks.add(245);
		
		Iterator<Integer> it = marks.descendingIterator();
		while(it.hasNext())
			System.out.println(it.next());
		
	}

}
