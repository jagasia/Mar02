package model;

import java.util.ArrayList;
import java.util.List;

public class StreamDemo3 {

	public static void main(String[] args) {
		List<String> countries=new ArrayList<String>();
		countries.add("India");
		countries.add("China");
		countries.add("Sri lanka");
		countries.add("Pakistan");
		countries.add("India");
		countries.add("China");
		countries.add("Bangladesh");
		countries.add("Zimbabwe");
		countries.add("Tanzania");
		countries.add("Afghanistan");
		
		countries.stream()
		.map((x)->x.length())
		.forEach(System.out::println);
	}

}
