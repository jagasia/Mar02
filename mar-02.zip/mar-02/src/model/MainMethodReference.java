package model;

import java.util.function.Consumer;

public class MainMethodReference {

	public static void doThis(String str, Consumer<String> consumer)	//method ref
	{
//		System.out.println("Hi "+str);
		str=str.toUpperCase();
		consumer.accept(str);
	}
	
	public static void main(String[] args) {
		doThis("India", System.out::println);
	}

}
