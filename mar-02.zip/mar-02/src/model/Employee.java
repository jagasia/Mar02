package model;

import java.io.Serializable;

public class Employee implements Serializable {
	private Integer employeeId;
	private String name;
	private String type;
	public Employee() {}
	public Employee(Integer employeeId, String name, String type) {
		super();
		this.employeeId = employeeId;
		this.name = name;
		this.type = type;
	}
	public Integer getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", name=" + name + ", type=" + type + "]";
	}
	
}
