package model;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Map;
import java.util.TreeMap;

public class EmployeeDao implements IEmployeeDao {
	private Map<Integer, Employee> employeeMap;
	public EmployeeDao()
	{
		employeeMap=new TreeMap<Integer, Employee>();
	}
	@Override
	public void create(Employee employee)
	{
		employeeMap.put(employee.getEmployeeId(), employee);
		store();
	}
	@Override
	public Map<Integer, Employee> read()
	{
		load();
		return this.employeeMap;
	}
	@Override
	public Employee read(Integer employeeId)
	{
		load();
		return this.employeeMap.get(employeeId);
	}
	@Override
	public void update(Employee employee)
	{
		create(employee);
		store();
	}
	@Override
	public void delete(Integer employeeId)
	{
		employeeMap.remove(employeeId);
		store();
	}
	@Override
	public void store() 
	{
		FileOutputStream fos=null;
		ObjectOutputStream oos=null;
		try {
		fos=new FileOutputStream("employees.dat");
		oos=new ObjectOutputStream(fos);
		oos.writeObject(employeeMap);
		
		}catch(IOException ioe)
		{
			
		}
		finally {
			try {
				oos.flush();
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
	}
	@Override
	public void load() 
	{
		try {
		FileInputStream fis=new FileInputStream("employees.dat");
		ObjectInputStream ois=new ObjectInputStream(fis);
		employeeMap=(Map<Integer, Employee>) ois.readObject();
		}catch(IOException | ClassNotFoundException cnf)
		{
			
		}
	}
}
