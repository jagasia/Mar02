package model;

import java.util.function.BiFunction;

interface Person
{
	void speak();
}

class Student	//implements Person
{
	public void talk()
	{
		System.out.println("Student talks");
	}
	public void talk(int x)
	{
		System.out.println(x);
	}
	public void speak()
	{
		System.out.println("Speaking");
	}
	public static int sum(int i, int j)
	{
		return i+j;
	}
}

public class MethodRef2 {

	public static void main(String[] args) {
		BiFunction<Integer, Integer, Integer> fn=Student::sum;
		int result=fn.apply(2,3);
		System.out.println(result);
	}

}
