package model;


interface Person
{
	void speak();
}

class Student	//implements Person
{
	public void talk()
	{
		System.out.println("Student talks");
	}
	public void talk(int x)
	{
		System.out.println(x);
	}
	public void speak()
	{
		System.out.println("Speaking");
	}
}

public class MethodRef2 {

	public static void main(String[] args) {
		Student siva=new Student();
		Person rama=siva::talk;
		rama.speak();

	}

}
