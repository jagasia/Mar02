package model;

import java.util.Map;

public interface IEmployeeDao {

	void create(Employee employee);

	Map<Integer, Employee> read();

	Employee read(Integer employeeId);

	void update(Employee employee);

	void delete(Integer employeeId);

	void store();

	void load();

}