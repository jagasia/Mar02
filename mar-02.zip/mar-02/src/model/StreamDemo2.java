package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.stream.Collectors;

public class StreamDemo2 {

	public static Employee createEmployee(String detail)
	{
		String[] arr = detail.split(",");
		Integer employeeId=Integer.valueOf(arr[0]);
		String name=arr[1];
		String type=arr[2];
		Employee employee=new Employee(employeeId, name, type);
		return employee;
	}
	public static void main(String[] args) {
		List<Employee> employeeList=new ArrayList<Employee>();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			Employee employee=createEmployee(detail);
			employeeList.add(employee);
		}
		Map<String, Long> result = employeeList.stream()
		.collect(Collectors.groupingBy(Employee::getType, Collectors.counting()));
		for(Entry<String, Long> e:result.entrySet())
			System.out.println(e.getKey()+"\t:\t"+e.getValue());
	}

}
