package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StreamDemo4 {
	public static Employee createEmployee(String detail)
	{
		String[] arr = detail.split(",");
		Integer employeeId=Integer.valueOf(arr[0]);
		String name=arr[1];
		String type=arr[2];
		Employee employee=new Employee(employeeId, name, type);
		return employee;
	}
	public static void main(String[] args) {
		List<Employee> employeeList=new ArrayList<Employee>();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			String detail=sc.nextLine();
			if(detail.equals(""))
				detail=sc.nextLine();
			Employee employee=createEmployee(detail);
			employeeList.add(employee);
		}
		
		employeeList.stream()
		.map((x)->x.getEmployeeId()+"\t"+x.getName().toUpperCase())
		.forEach(System.out::println);
	}
}
