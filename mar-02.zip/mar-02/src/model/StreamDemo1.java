package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

class MyPredicate implements Predicate<String>
{

	@Override
	public boolean test(String t) {
		// TODO Auto-generated method stub
		return t.substring(0,1).equals("A");
	}
	
}


public class StreamDemo1 {

	public static void main(String[] args) {
		List<String> countries=new ArrayList<String>();
		countries.add("India");
		countries.add("China");
		countries.add("Sri lanka");
		countries.add("Pakistan");
		countries.add("India");
		countries.add("China");
		countries.add("Bangladesh");
		countries.add("Zimbabwe");
		countries.add("Tanzania");
		countries.add("Afghanistan");
		
//		Stream<String> stream = countries.stream();
////		stream=stream.filter(new MyPredicate());
//		stream=stream.filter((x)->x.length()<=5);
//		stream.forEach((x)->System.out.println(x));
		Map<String, Long> result = countries.stream()
		.collect(Collectors.groupingBy(String::toString,Collectors.counting()));
//		.filter((x)->x.length()>5)
//		.filter((x)->!x.subSequence(0, 1).equals("A"))
//		.sorted((a,b)->b.compareTo(a))
//		.forEach(System.out::println);
		for(Entry<String,Long> e:result.entrySet())
			System.out.println(e.getKey()+"\t:\t"+e.getValue());
	}

}
