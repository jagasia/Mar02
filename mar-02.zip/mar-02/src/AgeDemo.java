import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class AgeDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
//		String s1=sc.nextLine();
//		String s2=sc.nextLine();
		LocalDate d1=LocalDate.of(1998, 1, 1);
		LocalDate d2=LocalDate.now();
		//to d1-d2
		Period result = Period.between(d1, d2);
		System.out.println(result);
		System.out.printf("You are %d year(s), %d month(s), %d day(s) young\n",result.getYears(), result.getMonths(), result.getDays());
		System.out.println("This is as of "+d2);
	}

}
