import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo {
	public static void main(String[] args) {
		Queue<String> countries=new PriorityQueue<>();
		countries.add("Sri lanka");
		countries.add("India");
		countries.add("Australia");
		countries.add("Pakistan");
		countries.add("Zimbabwe");
		countries.add("Bangladesh");
		
		while(!countries.isEmpty())
			System.out.println(countries.remove());
	}
}
