import java.util.EnumMap;

enum Days {MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY}
public class EnmMapDemo {

	public static void main(String[] args) {
		EnumMap<Days, Integer> map1=new EnumMap<>(Days.class);
		map1.put(Days.MONDAY, 8);
		map1.put(Days.WEDNESDAY, 10);	
	}
}
