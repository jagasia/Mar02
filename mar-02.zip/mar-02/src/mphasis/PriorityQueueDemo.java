package mphasis;

import java.util.PriorityQueue;

class Student
{
	private Integer id;
	private String name;
	private Integer mark;
	public Student() {}
	public Student(Integer id, String name, Integer mark) {
		super();
		this.id = id;
		this.name = name;
		this.mark = mark;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getMark() {
		return mark;
	}
	public void setMark(Integer mark) {
		this.mark = mark;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", mark=" + mark + "]";
	}
	
}
public class PriorityQueueDemo {

	public static void main(String[] args) {
		PriorityQueue<Student> students=new PriorityQueue<>((s2,s1)->s1.getMark().compareTo(s2.getMark()));
		students.add(new Student(45, "Raja", 89));
		students.add(new Student(145, "Abdul", 100));
		students.add(new Student(514, "Rajesh", 90));
		students.add(new Student(52, "Siva", 45));
		students.add(new Student(25, "Krishna", 54));
		students.add(new Student(53, "John", 80));
		students.add(new Student(35, "Jag", 59));
		students.add(new Student(533, "Dinesh", 70));
		
		while(!students.isEmpty())
			System.out.println(students.remove());
	}
}
