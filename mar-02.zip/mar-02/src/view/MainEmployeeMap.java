package view;

import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import model.Employee;
import model.EmployeeDao;
import model.IEmployeeDao;

public class MainEmployeeMap {

	public static Employee createEmployee(String detail)
	{
		String[] arr = detail.split(",");
		Integer employeeId=Integer.valueOf(arr[0]);
		String name=arr[1];
		String type=arr[2];
		Employee employee=new Employee(employeeId, name, type);
		return employee;
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IEmployeeDao edao=new EmployeeDao();
		Employee employee=null;
		Integer employeeId=0;
		String detail="";
		Map<Integer, Employee> employeeMap;
		int choice=0;
		do
		{
			System.out.println("		1) Add Employee\r\n" +
					"		2) Bulk add\r\n" +		 
					"		3) Modify EMployee\r\n" + 	 
					"		4) Remove Employee\r\n" +	 
					"		5) Display All Employees in asc\r\n" +	 
					"		6) Display All Employees in desc\r\n" + 
					"		7) Find Employee by Id\r\n" +	 
					"		8) Exit\r\n");
			choice=sc.nextInt();
			
			Set<Integer> set;
			switch(choice)
			{
			case 1:		//add
			case 3:		//modify
				System.out.println("Please enter the employee details(ID,NAME,TYPE)");
				detail=sc.nextLine();
				if(detail.equals(""))
					detail=sc.nextLine();
				employee=createEmployee(detail);
				edao.create(employee);
				System.out.printf("Employee %d added/updated successfully\n",employee.getEmployeeId());
				break;
			case 2:		//bulk add
				System.out.println("How many employees to be added?");
				int n=sc.nextInt();
				for(int i=0;i<n;i++)
				{
					detail=sc.nextLine();
					if(detail.equals(""))
						detail=sc.nextLine();
					employee=createEmployee(detail);
					edao.create(employee);
					System.out.printf("Employee %d added successfully\n",employee.getEmployeeId());
				}
				break;
			case 4:		//remove
				System.out.println("Enter the employee Id to remove");
				employeeId=sc.nextInt();
				edao.delete(employeeId);
				System.out.printf("Employee %d removed successfully\n",employeeId);
				break;
			case 5:		//display all in asc
				employeeMap = edao.read();
				for(Entry<Integer, Employee> e:employeeMap.entrySet())
					System.out.println(e.getValue());
				break;
			case 6:		//display all in desc
				//DescendingIterator is availabe for TreeSet.	How to get set from map?	(ans: keySet())
				employeeMap=edao.read();
				set =employeeMap.keySet();
				TreeSet set1=new TreeSet<>(set);
				Iterator<Integer> it = set1.descendingIterator();
				while(it.hasNext())
				{
					employeeId=it.next();
					employee=employeeMap.get(employeeId);
					System.out.println(employee);
				}
				break;
			case 7:		//find by id
				System.out.println("Enter the employee Id to find");
				employeeId=sc.nextInt();
				employee=edao.read(employeeId);
				System.out.println(employee);
				break;
			case 8:
				System.out.println("Thank you, visit again!");
				System.exit(0);
			}
		}while(true);
	}

}
