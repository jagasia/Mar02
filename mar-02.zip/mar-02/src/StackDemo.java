import java.util.Stack;

public class StackDemo {
	public static void main(String[] args) {
		Stack<Integer> stack=new Stack<Integer>();
		stack.push(10);
		stack.push(120);
		stack.push(310);
		stack.push(401);
		stack.push(250);
		stack.push(620);
			
		while(!stack.isEmpty())
			System.out.println(stack.pop());
	}
}
