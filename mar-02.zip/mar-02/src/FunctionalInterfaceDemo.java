@FunctionalInterface 
interface MyInterface
{
	void display();
//	void anotherMethod();
}

public class FunctionalInterfaceDemo {

	public static void main(String[] args) {
		
	}

}
